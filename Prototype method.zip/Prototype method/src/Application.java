public class Application {
    public static void main(String[] args) {
        Macbook mac = new Macbook( 8, 128, "Apple");

        System.out.println(mac.toString());

        Macbook cloneObj = mac.clone();
        System.out.println(cloneObj.toString());

        cloneObj.setRam(16);
        System.out.println(cloneObj);

        System.out.println(mac.toString());



    }
}
