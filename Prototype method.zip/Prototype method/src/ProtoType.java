public interface ProtoType {

    abstract Macbook clone();

}
